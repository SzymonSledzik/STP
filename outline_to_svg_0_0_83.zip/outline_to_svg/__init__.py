# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name": "Outlines To SVG",
    "author": "Ben Morrison",
    "description": "Export outline of selected objects",
    "blender": (2, 83, 0),
    "version": (0, 0, 83),
    "location": "",
    "warning": "",
    "category": "Import-Export",
}

# Built-ins
from pathlib import Path
import importlib
import os
from concurrent.futures import ThreadPoolExecutor
from itertools import repeat, chain
import sys

# Blender Built-ins
import bpy
from bpy.props import (
    BoolProperty,
    StringProperty,
    PointerProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
)
from mathutils import Vector

# Local Modules
from . import get_geo
from . import write_geo
from . import process_geo

importlib.reload(get_geo)
importlib.reload(write_geo)
importlib.reload(process_geo)


METRIC_UNITS = {
    "KILOMETERS": "km",
    "METERS": "m",
    "CENTIMETERS": "cm",
    "MILLIMETERS": "mm",
}

IMPERIAL_UNITS = {"FEET": "ft", "INCHES": "in"}

# Operators
################################################################################


class EXPORT_OT_Export_Outline_SVG(bpy.types.Operator):
    bl_idname = "export_mesh.export_outline_svg"
    bl_label = "Export Outline to SVG"
    bl_options = {"REGISTER", "INTERNAL"}

    filepath: StringProperty(name="Output Path", subtype="FILE_PATH")
    # use_camera: BoolProperty(name="Use Camera", default=False)

    @classmethod
    def poll(cls, context):
        return all((len(context.selected_objects) != 0, context.area.type == "VIEW_3D"))

    def get_region_view_type(self, context):
        """ return one of [‘PERSP’, ‘ORTHO’, ‘CAMERA’] """
        area = context.area
        rv3d = area.spaces[0].region_3d
        return rv3d.view_perspective

    def is_valid_projector(self, context):
        if self.get_region_view_type(context) == "ORTHO":
            return True
        if self.get_region_view_type(context) == "CAMERA":
            return context.scene.camera.data.type == "ORTHO"
        return False

    def is_camera_projector(self, context):
        return self.get_region_view_type(context) == "CAMERA"

    def get_units_string(self, context):
        user_units = context.scene.unit_settings.length_unit
        unit_sys = context.scene.unit_settings.system
        if unit_sys == "METRIC" and user_units in METRIC_UNITS.keys():
            return METRIC_UNITS[user_units]
        elif unit_sys == "IMPERIAL" and user_units in IMPERIAL_UNITS.keys():
            return IMPERIAL_UNITS[user_units]
        else:
            return ""

    def validate_filepath(self):
        if self.filepath == "":
            self.report({"WARNING"}, "No filepath selected")
            return {"CANCELLED"}

        # Ensure valid filepath
        self.filepath = bpy.path.abspath(self.filepath)

        if os.path.isdir(self.filepath):
            self.filepath = os.path.join(self.filepath, "svg_export.svg")

        self.filepath = bpy.path.ensure_ext(self.filepath, ".svg")

    def execute(self, context: bpy.types.Context):
        self.validate_filepath()

        if not self.is_valid_projector(context):
            self.report({"WARNING"}, "Only Orthographic views are supported")
            return {"CANCELLED"}

        valid_target_types = [
            "MESH",
            "SURFACE",
            "CURVE",
            "META",
            "FONT",
        ]

        targets = [o for o in context.selected_objects if o.type in valid_target_types]
        if not targets:
            self.report({"WARNING"}, "No valid targets selected")
            return {"CANCELLED"}

        area = context.area
        rv3d = area.spaces[0].region_3d
        view_rotation = rv3d.view_rotation

        invert_view_rot = view_rotation.to_matrix().to_4x4().inverted()

        face_sets = [
            get_geo.get_flattened_faces(context, obj, invert_view_rot)
            for obj in targets
        ]

        # Set origin
        # find min-x min-y
        origin_offset = None
        if self.is_camera_projector(context):
            view_frame = get_geo.get_camera_frame(
                context, invert_view_rot, flatten=True
            )
            for v in view_frame:
                v.y *= -1  # Note: Ugh
                if origin_offset is None:
                    origin_offset = v.copy()
                    continue
                origin_offset.x = min(origin_offset.x, v.x)
                origin_offset.y = min(origin_offset.y, v.y)

        else:
            for face_set in face_sets:
                for face in face_set:
                    for v in face:
                        if origin_offset is None:
                            origin_offset = v.copy()
                            continue
                        origin_offset.x = min(origin_offset.x, v.x)
                        origin_offset.y = min(origin_offset.y, v.y)

        loc_correction = origin_offset * -1
        # print("\n\nloc correct\t", loc_correction)

        # Cancel offset
        if self.is_camera_projector(context):
            view_frame = [loc_correction + v for v in view_frame]

        # Make position and origin relative
        face_sets = [
            process_geo.translate_face_set(face_set, loc_correction)
            for face_set in face_sets
        ]

        if self.is_camera_projector(context):
            frame_origin = get_geo.avg_vectors(view_frame)
        else:
            frame_origin = get_geo.get_face_sets_origin(face_sets)

        # Convert targets to shapely polygons
        poly_sets = [get_geo.faces_to_polygons(face_set) for face_set in face_sets]

        # Perform union operation
        with ThreadPoolExecutor() as executor:
            # buffer = 0.001
            buffer = 0.00001
            merged_sets = executor.map(
                process_geo.poly_union, poly_sets, repeat(buffer)
            )

        # Flatten merged face sets
        merged = list(chain.from_iterable(merged_sets))

        if not self.is_camera_projector(context):
            svg_bounds = process_geo.get_bbox(merged)
            # print('svg bounds:\t', svg_bounds)
        else:
            # Get camera frame
            # print('cam bound:\t', view_frame)
            cam_projection_bounds = [view_frame[2], view_frame[0]]

            svg_bounds = (
                cam_projection_bounds[0].to_tuple()
                + cam_projection_bounds[1].to_tuple()
            )

        units = self.get_units_string(context)

        write_geo.write_poly_to_svg(
            self.filepath, merged, svg_bounds[:2], svg_bounds[2:], units
        )
        return {"FINISHED"}


# Props
###############################################################################


class Outlines_To_SVG_Properties(bpy.types.PropertyGroup):
    """ Addon panel UI properties """

    filepath: StringProperty(name="Output Path", subtype="FILE_PATH")


# UI
###############################################################################


class VIEW3D_PT_Outline_To_SVG(bpy.types.Panel):
    bl_label = "Outline to SVG"
    bl_idname = "SCENE_PT_outline_to_svg"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Outline To SVG"

    def draw(self, context):
        # wm = bpy.context.window_manager
        addon_props = context.scene.outline_to_svg_props

        layout = self.layout
        col = layout.column(align=True)
        row = col.row(align=True)
        row.label(text="Export")
        row = col.row(align=True)
        row.prop(addon_props, "filepath", text="")
        row = col.row(align=True)
        btn = row.operator(EXPORT_OT_Export_Outline_SVG.bl_idname, text="Export SVG")
        btn.filepath = addon_props.filepath


# Registration
###############################################################################

classes = [
    EXPORT_OT_Export_Outline_SVG,
    VIEW3D_PT_Outline_To_SVG,
]


def register():
    if "shapely" not in sys.modules:
        from .utils_pip import Pip

        Pip._ensure_user_site_package()
        Pip.install("shapely")

    # Properties
    bpy.utils.register_class(Outlines_To_SVG_Properties)
    bpy.types.Scene.outline_to_svg_props = PointerProperty(
        type=Outlines_To_SVG_Properties
    )

    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    bpy.utils.unregister_class(Outlines_To_SVG_Properties)
    del bpy.types.Scene.outline_to_svg_props
    for cls in classes:
        bpy.utils.unregister_class(cls)
